import java.util.LinkedList;
import java.util.Queue;

public class Maze {
    
    Location[][] grid;
    
    public Maze(char[][] charMaze) {
        // You need to write this constructor.
        grid = new Location[charMaze.length][charMaze[0].length];
        for(int i = 0; i < grid.length; i++){
            for(int j = 0; j < grid[0].length; j++){
                if(charMaze[i][j] == '.'){
                    grid[i][j] = new Location(i, j, true);
                }
                else if(charMaze[i][j] == 'X'){
                    grid[i][j] = new Location(i, j, false);
                }
            }
        }
        
        
    }
    
    // YOU DO NOT NEED TO MODIFY THIS METHOD, and you do not need to use it.
    // It is just here to allow me to write helpful tests for your code.
    public Location[][] getGrid() {
        return grid;
    }
    
    public LinkedList<Location> shortestPath(int startRow, int startCol, int endRow, int endCol) {
        LinkedList<Location> shortPath = new LinkedList<Location>();
        Queue<Location> q = new LinkedList<Location>();
        Location loc = grid[startRow][startCol];
        loc.markAsVisited();
        q.add(loc);
        
        while(!(q.isEmpty())){
            Location a = q.remove();
            
            if(a == grid[endRow][endCol]){
                return shortPath = backtracePath(a);
            }
            
            shortPath = getUnvisitedOpenNeighbors(a);
            for(int i = 0; i < shortPath.size(); i++){
                shortPath.get(i).markAsVisited();
                shortPath.get(i).setPreviousLocation(a);
                q.add(shortPath.get(i));
                
            }
        }
        
        return shortPath;
    }
    
    public LinkedList<Location> getUnvisitedOpenNeighbors(Location current) {
       
        LinkedList<Location> neighbors = new LinkedList<Location>();
        int row = current.getRow();
        int col = current.getCol();
        
        if(row > 0){
            if(grid[row - 1][col].isOpen() && !(grid[row - 1][col].isVisited())){
                neighbors.add(grid[row - 1][col]);
            }
        }
        if(row < grid.length - 1){
            if(grid[row + 1][col].isOpen() && !(grid[row + 1][col].isVisited())){
                neighbors.add(grid[row + 1][col]);
            }
        }
        if(col > 0){
            if(grid[row][col - 1].isOpen() && !(grid[row][col - 1].isVisited())){
                neighbors.add(grid[row][col - 1]);
            }
        }
        if(col < grid[0].length - 1){
            if(grid[row][col + 1].isOpen() && !(grid[row][col + 1].isVisited())){
                neighbors.add(grid[row][col + 1]);
            }
        }

        return neighbors;
    }
    
    public static LinkedList<Location> backtracePath(Location goal) {
        LinkedList<Location> path = new LinkedList<Location>();
        path.addLast(goal);
        Location current = goal;
        int counter = 1;
        while(current.getPreviousLocation() != null){
            path.add(path.size() - counter, current.getPreviousLocation());
            current = current.getPreviousLocation();
            counter++;
        }
        
        return path;
    }
    
}